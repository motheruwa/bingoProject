npm i

npx prisma generate

npm run migrate

npm run dev